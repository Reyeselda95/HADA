
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using InariPlaysGenNHibernate.EN.Prueba;
using InariPlaysGenNHibernate.CAD.Prueba;

namespace InariPlaysGenNHibernate.CEN.Prueba
{
public partial class ProductoCEN
{
public void DecrementarStock (int p_oid, int p_cantidad)
{
        /*PROTECTED REGION ID(InariPlaysGenNHibernate.CEN.Prueba_Producto_decrementarStock) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method DecrementarStock() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

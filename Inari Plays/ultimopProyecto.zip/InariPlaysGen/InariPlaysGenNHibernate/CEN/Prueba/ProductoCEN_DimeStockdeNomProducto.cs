
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using InariPlaysGenNHibernate.EN.Prueba;
using InariPlaysGenNHibernate.CAD.Prueba;

namespace InariPlaysGenNHibernate.CEN.Prueba
{
public partial class ProductoCEN
{
public void DimeStockdeNomProducto (string nombreproducto)
{
        /*PROTECTED REGION ID(InariPlaysGenNHibernate.CEN.Prueba_Producto_DimeStockdeNomProducto) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method DimeStockdeNomProducto() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

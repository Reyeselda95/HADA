
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using InariPlaysGenNHibernate.EN.Prueba;
using InariPlaysGenNHibernate.CAD.Prueba;

namespace InariPlaysGenNHibernate.CEN.Prueba
{
public partial class AdministradorCEN
{
public void Logearse (int p_oid, string contraseña)
{
        /*PROTECTED REGION ID(InariPlaysGenNHibernate.CEN.Prueba_Administrador_logearse) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Logearse() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

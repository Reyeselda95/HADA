
using System;

namespace InariPlaysGenNHibernate.Enumerated.Prueba
{
public enum EstadoPedidoEnum { pendiente=1, enviado=2, cancelado=3, recibido=4 };
}

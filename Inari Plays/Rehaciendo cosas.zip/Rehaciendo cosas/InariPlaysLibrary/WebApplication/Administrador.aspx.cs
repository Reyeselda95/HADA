﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using InariPlaysLibrary.CAD;
using InariPlaysLibrary.EN;

namespace WebApplication
{
    public partial class Administrador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //En esta función muestra los clientes y esta conectado a la base de datos
        public void Mostrarusuarios(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.ClienteEN> clientes = null;
            ClienteEN cli = new ClienteEN();

            clientes = cli.dameTodosClientes();

            foreach(ClienteEN clien in clientes)
            {
                //NIF
                Label niff = new Label();
                niff.Text = "NIF:";
                Content3.Controls.Add(niff);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label n = new Label();
                n.Text = cli.NIF;
                Content3.Controls.Add(n);

                Content3.Controls.Add(new LiteralControl("<br>"));

                //nombre
                Label nom = new Label();
                nom.Text = "nombre:";
                Content3.Controls.Add(nom);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label d = new Label();
                d.Text = cli.Nombre;
                Content3.Controls.Add(d);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //email
                Label ema = new Label();
                ema.Text = "email:";
                Content3.Controls.Add(ema);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label v = new Label();
                v.Text = cli.Email;
                Content3.Controls.Add(v);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //password
                Label pass = new Label();
                pass.Text = "password:";
                Content3.Controls.Add(pass);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label o = new Label();
                o.Text = cli.Password;
                Content3.Controls.Add(o);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //apellidos
                Label ape = new Label();
                ape.Text = "apellidos:";
                Content3.Controls.Add(ape);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label w = new Label();
                w.Text = cli.Apellidos;
                Content3.Controls.Add(w);

                Content3.Controls.Add(new LiteralControl("<br>"));

                //direccion
                Label dir = new Label();
                dir.Text = "direccion:";
                Content3.Controls.Add(dir);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label z = new Label();
                z.Text = cli.Direccion;
                Content3.Controls.Add(z);

                Content3.Controls.Add(new LiteralControl("<br>"));

                //telefono
                Label telf = new Label();
                telf.Text = "telefono:";
                Content3.Controls.Add(telf);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label h = new Label();
                h.Text = cli.Telefono;
                Content3.Controls.Add(h);

                Content3.Controls.Add(new LiteralControl("<br>"));

                //codigo postal
                Label cpos = new Label();
                cpos.Text = "cod.pos:";
                Content3.Controls.Add(cpos);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label y = new Label();
                y.Text = cli.Cp.ToString();
                Content3.Controls.Add(y);

                Content3.Controls.Add(new LiteralControl("<br>"));
            }       
        }

        public void mostrarproductos(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.ProductoEN> productos = null;
            ProductoEN produc = new ProductoEN();

            productos = produc.dameTodosProductos();

            foreach (ProductoEN prod in productos)
            {
                //productoid
                Label iden = new Label();
                iden.Text = "Identificador:";
                Content3.Controls.Add(iden);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label n = new Label();
                n.Text = prod.ProductoId.ToString();
                Content3.Controls.Add(n);

                Content3.Controls.Add(new LiteralControl("<br>"));

                //nombre
                Label nombr = new Label();
                nombr.Text = "Nombre:";
                Content3.Controls.Add(nombr);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label q = new Label();
                q.Text = prod.Nombre;
                Content3.Controls.Add(q);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //descripcion
                Label descp = new Label();
                descp.Text = "Descripcion:";
                Content3.Controls.Add(descp);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label j = new Label();
                j.Text = prod.Descripcion;
                Content3.Controls.Add(j);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //precio
                Label precio = new Label();
                precio.Text = "precio:";
                Content3.Controls.Add(precio);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label p = new Label();
                p.Text = prod.Precio.ToString();
                Content3.Controls.Add(p);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //stock
                Label stoc = new Label();
                stoc.Text = "stock:";
                Content3.Controls.Add(stoc);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label s = new Label();
                s.Text = prod.Stock.ToString();
                Content3.Controls.Add(s);

                Content3.Controls.Add(new LiteralControl("<br>"));

            }
        }

        public void mostrarpedidos(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.PedidoEN> pedidos = null;
            PedidoEN pedid = new PedidoEN();

            pedidos = pedid.dameTodosPedidos();

            foreach (PedidoEN pedi in pedidos)
            {
                //pedidoid
                Label iden = new Label();
                iden.Text = "identificador:";
                Content3.Controls.Add(iden);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label s = new Label();
                s.Text = pedi.PedidoId.ToString();
                Content3.Controls.Add(s);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //fecha
                Label dat = new Label();
                dat.Text = "fecha:";
                Content3.Controls.Add(dat);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label j = new Label();
                j.Text = pedi.Fecha.ToString();
                Content3.Controls.Add(j);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //direccion
                Label dire = new Label();
                dire.Text = "direccion:";
                Content3.Controls.Add(dire);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label q = new Label();
                q.Text = pedi.Direccion;
                Content3.Controls.Add(q);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //cp
                Label cpo = new Label();
                cpo.Text = "cod.pos:";
                Content3.Controls.Add(cpo);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label h = new Label();
                h.Text = pedi.CodigoPostal.ToString();
                Content3.Controls.Add(h);

                Content3.Controls.Add(new LiteralControl("<br>"));


                //tipo pago
                Label tip = new Label();
                tip.Text = "tipo pago:";
                Content3.Controls.Add(tip);
                Content3.Controls.Add(new LiteralControl("&nbsp"));
                Label l = new Label();
                l.Text = pedi.TipoPago;
                Content3.Controls.Add(l);

                Content3.Controls.Add(new LiteralControl("<br>"));

            }
        }

        public void insertarproducto(object sender, EventArgs e)
        {


        }       
    }
}
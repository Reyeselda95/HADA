
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using InariPlaysGenNHibernate.EN.Prueba;
using InariPlaysGenNHibernate.CAD.Prueba;

namespace InariPlaysGenNHibernate.CEN.Prueba
{
public partial class ClienteCEN
{
public bool Logarse (string p_oid, string password)
{
        /*PROTECTED REGION ID(InariPlaysGenNHibernate.CEN.Prueba_Cliente_logarse) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method Logarse() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

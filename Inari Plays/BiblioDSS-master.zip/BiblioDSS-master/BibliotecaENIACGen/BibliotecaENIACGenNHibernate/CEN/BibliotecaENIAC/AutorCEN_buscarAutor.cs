
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class AutorCEN
{
public BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC.AutorEN BuscarAutor (string p_Autor_OID)
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_Autor_buscarAutor) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method BuscarAutor() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}


using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class EjemplarCEN
{
public bool EstaPrestado (int p_oid)
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_Ejemplar_estaPrestado) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method EstaPrestado() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

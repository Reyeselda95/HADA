
using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class UsuarioCEN
{
public void ModificarDesiderata (string p_oid)
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_Usuario_modificarDesiderata) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method ModificarDesiderata() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}


using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class ObraCEN
{
public void BuscaPorNombre (string nombre)
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_Obra_buscaPorNombre) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method BuscaPorNombre() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}


using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class BibliografiaRecomendadaCEN
{
public System.Collections.Generic.IList<BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC.BibliografiaRecomendadaEN> ListarObrasRecomendadas ()
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_BibliografiaRecomendada_listarObrasRecomendadas) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method ListarObrasRecomendadas() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}


using System;
using System.Text;

using NHibernate;
using NHibernate.Cfg;
using NHibernate.Criterion;
using NHibernate.Exceptions;

using BibliotecaENIACGenNHibernate.EN.BibliotecaENIAC;
using BibliotecaENIACGenNHibernate.CAD.BibliotecaENIAC;

namespace BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC
{
public partial class PrestamoCEN
{
public bool RenovarPrestamo (string p_oid)
{
        /*PROTECTED REGION ID(BibliotecaENIACGenNHibernate.CEN.BibliotecaENIAC_Prestamo_renovarPrestamo) ENABLED START*/

        // Write here your custom code...

        throw new NotImplementedException ("Method RenovarPrestamo() not yet implemented.");

        /*PROTECTED REGION END*/
}
}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using InariPlaysLibrary.CAD;
using InariPlaysLibrary.EN;

namespace WebApplication
{
    public partial class Administrador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void Mostrarusuarios(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.ClienteEN> clientes = null;
            ClienteEN cli = new ClienteEN();

            clientes = cli.dameTodosClientes();

            foreach(ClienteEN clien in clientes)
            {
                //NIF
                Label niff = new Label();
                niff.Text = "NIF:";
                Panel1.Controls.Add(niff);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label n = new Label();
                n.Text = cli.NIF;
                Panel1.Controls.Add(n);

                Panel1.Controls.Add(new LiteralControl("<br>"));

                //nombre
                Label nom = new Label();
                nom.Text = "nombre:";
                Panel1.Controls.Add(nom);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label d = new Label();
                d.Text = cli.Nombre;
                Panel1.Controls.Add(d);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //email
                Label ema = new Label();
                ema.Text = "email:";
                Panel1.Controls.Add(ema);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label v = new Label();
                v.Text = cli.Email;
                Panel1.Controls.Add(v);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //password
                Label pass = new Label();
                pass.Text = "password:";
                Panel1.Controls.Add(pass);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label o = new Label();
                o.Text = cli.Password;
                Panel1.Controls.Add(o);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //apellidos
                Label ape = new Label();
                ape.Text = "apellidos:";
                Panel1.Controls.Add(ape);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label w = new Label();
                w.Text = cli.Apellidos;
                Panel1.Controls.Add(w);

                Panel1.Controls.Add(new LiteralControl("<br>"));

                //direccion
                Label dir = new Label();
                dir.Text = "direccion:";
                Panel1.Controls.Add(dir);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label z = new Label();
                z.Text = cli.Direccion;
                Panel1.Controls.Add(z);

                Panel1.Controls.Add(new LiteralControl("<br>"));

                //telefono
                Label telf = new Label();
                telf.Text = "telefono:";
                Panel1.Controls.Add(telf);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label h = new Label();
                h.Text = cli.Telefono;
                Panel1.Controls.Add(h);

                Panel1.Controls.Add(new LiteralControl("<br>"));

                //codigo postal
                Label cpos = new Label();
                cpos.Text = "cod.pos:";
                Panel1.Controls.Add(cpos);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label y = new Label();
                y.Text = cli.Cp.ToString();
                Panel1.Controls.Add(y);

                Panel1.Controls.Add(new LiteralControl("<br>"));
            }       
        }

        public void mostrarproductos(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.ProductoEN> productos = null;
            ProductoEN produc = new ProductoEN();

            productos = produc.dameTodosProductos();

            foreach (ProductoEN prod in productos)
            {
                //productoid
                Label iden = new Label();
                iden.Text = "Identificador:";
                Panel1.Controls.Add(iden);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label n = new Label();
                n.Text = prod.ProductoId.ToString();
                Panel1.Controls.Add(n);

                Panel1.Controls.Add(new LiteralControl("<br>"));

                //nombre
                Label nombr = new Label();
                nombr.Text = "Nombre:";
                Panel1.Controls.Add(nombr);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label q = new Label();
                q.Text = prod.Nombre;
                Panel1.Controls.Add(q);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //descripcion
                Label descp = new Label();
                descp.Text = "Descripcion:";
                Panel1.Controls.Add(descp);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label j = new Label();
                j.Text = prod.Descripcion;
                Panel1.Controls.Add(j);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //precio
                Label precio = new Label();
                precio.Text = "precio:";
                Panel1.Controls.Add(precio);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label p = new Label();
                p.Text = prod.Precio.ToString();
                Panel1.Controls.Add(p);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //stock
                Label stoc = new Label();
                stoc.Text = "stock:";
                Panel1.Controls.Add(stoc);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label s = new Label();
                s.Text = prod.Stock.ToString();
                Panel1.Controls.Add(s);

                Panel1.Controls.Add(new LiteralControl("<br>"));

            }
        }

        public void mostrarpedidos(object sender, EventArgs e)
        {
            System.Collections.Generic.IList<InariPlaysLibrary.EN.PedidoEN> pedidos = null;
            PedidoEN pedid = new PedidoEN();

            pedidos = pedid.dameTodosPedidos();

            foreach (PedidoEN pedi in pedidos)
            {
                //pedidoid
                Label iden = new Label();
                iden.Text = "identificador:";
                Panel1.Controls.Add(iden);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label s = new Label();
                s.Text = pedi.PedidoId.ToString();
                Panel1.Controls.Add(s);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //fecha
                Label dat = new Label();
                dat.Text = "fecha:";
                Panel1.Controls.Add(dat);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label j = new Label();
                j.Text = pedi.Fecha.ToString();
                Panel1.Controls.Add(j);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //direccion
                Label dire = new Label();
                dire.Text = "direccion:";
                Panel1.Controls.Add(dire);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label q = new Label();
                q.Text = pedi.Direccion;
                Panel1.Controls.Add(q);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //cp
                Label cpo = new Label();
                cpo.Text = "cod.pos:";
                Panel1.Controls.Add(cpo);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label h = new Label();
                h.Text = pedi.CodigoPostal.ToString();
                Panel1.Controls.Add(h);

                Panel1.Controls.Add(new LiteralControl("<br>"));


                //tipo pago
                Label tip = new Label();
                tip.Text = "tipo pago:";
                Panel1.Controls.Add(tip);
                Panel1.Controls.Add(new LiteralControl("&nbsp"));
                Label l = new Label();
                l.Text = pedi.TipoPago;
                Panel1.Controls.Add(l);

                Panel1.Controls.Add(new LiteralControl("<br>"));

            }
        }

        public void insertarproducto(object sender, EventArgs e)
        {
            ProductoEN produc = new ProductoEN();

            produc.ProductoId = Convert.ToInt32(producid.Text);
            produc.Nombre = nomproduc.Text;
            produc.Descripcion = produdesc.Text;
            produc.Precio = Convert.ToUInt32(produprecio.Text);
            produc.Stock =  Convert.ToInt32(produproc.Text);
        }       
    }
}
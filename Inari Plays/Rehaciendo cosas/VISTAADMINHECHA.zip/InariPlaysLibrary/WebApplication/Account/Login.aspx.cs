﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using WebApplication;
using InariPlaysLibrary.CAD;
using InariPlaysLibrary.EN; 

namespace WebApplication.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register";
   

            var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            if (!String.IsNullOrEmpty(returnUrl))
            {
                RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            }
        }

        public void logeaclick(object sender, EventArgs e)
        {

            ClienteEN cliente = new ClienteEN();
            
            Session[""] = LoginUser.UserName;
            Session[""] = LoginUser.Password;

            string usuario = Convert.ToString(Session[]);
            string contrase = Convert.ToString(Session[]);

            Session.Timeout = 10000;
        }
    }
}